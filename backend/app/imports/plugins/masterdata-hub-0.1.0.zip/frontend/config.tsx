import React, {useCallback, useEffect, useState} from "react";
import {createRoot} from "react-dom/client";
import {ValtimoPluginSDK} from "@valtimo/plugin-sdk/frontend";

const sdk = new ValtimoPluginSDK();

function ConfigForm() {
  const [title, setTitle] = useState("");
  const [hubUrl, setHubUrl] = useState("http://localhost:8090");
  const [tokenUrl, setTokenUrl] = useState("http://localhost:8081/auth/realms/valtimo/protocol/openid-connect/token");
  const [clientId, setClientId] = useState("masterdata-hub-client");
  const [clientSecret, setClientSecret] = useState("");

  useEffect(() => {
    sdk.onPrefillConfiguration(({title: prefillTitle, configuration}) => {
      if (prefillTitle) setTitle(prefillTitle);
      if (configuration.hubUrl) setHubUrl(configuration.hubUrl as string);
      if (configuration.tokenUrl) setTokenUrl(configuration.tokenUrl as string);
      if (configuration.clientId) setClientId(configuration.clientId as string);
      if (configuration.clientSecret) setClientSecret(configuration.clientSecret as string);
    });
    sdk.onSave(() => {});
    sdk.emit("ready", {});
  }, []);

  const emit = useCallback((
    nextTitle: string,
    nextHubUrl: string,
    nextTokenUrl: string,
    nextClientId: string,
    nextClientSecret: string
  ) => {
    const isValid =
      nextTitle.trim().length > 0 &&
      nextHubUrl.trim().length > 0 &&
      nextTokenUrl.trim().length > 0 &&
      nextClientId.trim().length > 0 &&
      nextClientSecret.trim().length > 0;
    sdk.setConfiguration(isValid, nextTitle.trim(), {
      hubUrl: nextHubUrl.trim(),
      tokenUrl: nextTokenUrl.trim(),
      clientId: nextClientId.trim(),
      clientSecret: nextClientSecret.trim(),
    });
  }, []);

  const inputStyle = {width: "100%", padding: "8px", border: "1px solid #ccc", borderRadius: "4px"};
  const labelStyle = {display: "block", marginBottom: "4px", fontWeight: 500};
  const helpStyle = {margin: "4px 0 0", fontSize: "12px", color: "#666"};

  return (
    <div style={{fontFamily: "IBM Plex Sans, sans-serif", display: "flex", flexDirection: "column", gap: "16px"}}>
      <div>
        <label style={labelStyle}>
          {sdk.t("config.title.label")}
        </label>
        <input
          type="text"
          value={title}
          onChange={(e) => { setTitle(e.target.value); emit(e.target.value, hubUrl, tokenUrl, clientId, clientSecret); }}
          placeholder={sdk.t("config.title.placeholder")}
          style={inputStyle}
        />
      </div>
      <div>
        <label style={labelStyle}>
          {sdk.t("config.hubUrl.label")}
        </label>
        <input
          type="text"
          value={hubUrl}
          onChange={(e) => { setHubUrl(e.target.value); emit(title, e.target.value, tokenUrl, clientId, clientSecret); }}
          placeholder={sdk.t("config.hubUrl.placeholder")}
          style={inputStyle}
        />
        <p style={helpStyle}>
          {sdk.t("config.hubUrl.help")}
        </p>
      </div>

      <hr style={{border: "none", borderTop: "1px solid #eee", margin: "8px 0"}} />
      <h4 style={{margin: 0, fontWeight: 500}}>OAuth2 Authentication</h4>

      <div>
        <label style={labelStyle}>
          {sdk.t("config.tokenUrl.label")}
        </label>
        <input
          type="text"
          value={tokenUrl}
          onChange={(e) => { setTokenUrl(e.target.value); emit(title, hubUrl, e.target.value, clientId, clientSecret); }}
          placeholder={sdk.t("config.tokenUrl.placeholder")}
          style={inputStyle}
        />
        <p style={helpStyle}>
          {sdk.t("config.tokenUrl.help")}
        </p>
      </div>
      <div>
        <label style={labelStyle}>
          {sdk.t("config.clientId.label")}
        </label>
        <input
          type="text"
          value={clientId}
          onChange={(e) => { setClientId(e.target.value); emit(title, hubUrl, tokenUrl, e.target.value, clientSecret); }}
          placeholder={sdk.t("config.clientId.placeholder")}
          style={inputStyle}
        />
        <p style={helpStyle}>
          {sdk.t("config.clientId.help")}
        </p>
      </div>
      <div>
        <label style={labelStyle}>
          {sdk.t("config.clientSecret.label")}
        </label>
        <input
          type="password"
          value={clientSecret}
          onChange={(e) => { setClientSecret(e.target.value); emit(title, hubUrl, tokenUrl, clientId, e.target.value); }}
          placeholder={sdk.t("config.clientSecret.placeholder")}
          style={inputStyle}
        />
        <p style={helpStyle}>
          {sdk.t("config.clientSecret.help")}
        </p>
      </div>
    </div>
  );
}

sdk.ready().then(() => createRoot(document.getElementById("root")!).render(<ConfigForm />));
